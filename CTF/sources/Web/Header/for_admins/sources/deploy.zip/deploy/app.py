from flask import Flask, request, jsonify, render_template
import random
from datetime import datetime
import logging
import math
app = Flask(__name__)

# Define the flag
FLAG = "EclipseCTF{834ut1ful_u53r_463nt}"


def fixed_datetime_random(datetime_string, start=5000, end=9999):
    dt_object = datetime.strptime(datetime_string, "%Y-%m-%d %H:%M:%S")
    seed_value = int(dt_object.strftime("%Y%m%d%H%M%S"))
    random.seed(seed_value)
    return random.randint(start, end)


@app.route('/')
def home():
    return render_template("index.html")

@app.route('/help')
def help():
    return render_template("help.html")

@app.route('/current_time', methods=['GET'])
def current_time():
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return jsonify(current_time=current_datetime), 200


@app.route('/flag', methods=['GET'])
def get_flag():
    # Check for User-Agent header with 'Windows 98'
    user_agent = request.headers.get('User-Agent')
    time_agent = request.headers.get('TimeStamp')
    random_agent = request.headers.get('RandintStamp')

    # Truncate current datetime to seconds (for comparison)
    current_dateTime_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Generate random integer based on provided timestamp
    rrand = fixed_datetime_random(time_agent) if time_agent else None

    # Check conditions in the correct sequence
    if not user_agent or "Windows 98" not in user_agent:
        return jsonify(error="User-Agent header incorrect or missing."), 403
    else:
        print(time_agent, current_dateTime_str)
        print(str(time_agent) == str(current_dateTime_str))
        if not time_agent or str(time_agent) != str(current_dateTime_str):
            return jsonify(error="not so fast need header TimeStamp %Y-%m-%d %H:%M:%S and it needs to be correct"), 200
        else:
            if not random_agent or str(rrand) != random_agent:
                if abs(abs(int(rrand)) - abs(int(random_agent))) < 5:
                    return jsonify(error=f"not SO CLOSE! {rrand}"), 200
                else:
                    return jsonify(error=f"not so fast need header RandintStamp this is last one! GO ON!!))) {rrand} /help /help /help"), 200
            else:
                # All conditions met, return the flag
                return jsonify(flag=FLAG), 200

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5758)