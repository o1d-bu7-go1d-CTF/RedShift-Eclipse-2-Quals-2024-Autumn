import re
from flask import Flask, request, jsonify, render_template
import logging
import requests
import socket  # Import the socket module
from urllib.parse import urlparse
app = Flask(__name__)

# WAF function to block specific URL payloads
def waf():
    def decorator(func):
        def wrapper(*args, **kwargs):
            target_url = request.args.get('url')
            if target_url:
                # Define regex patterns to match against malicious Gopher payloads
                gopher_patterns = [
                    r'gopher',           # Matches Gopher protocol
                    r'localhost',           # Prevents localhost Gopher requests
                    r'0\.0\.0\.0',          # Prevents all interfaces
                    r'127\.0\.0\.1',        # Prevents localhost
                    r'\.\./',               # Path traversal attempts
                    r'(?i)(flag|secret)',   # Detect specific keywords like 'flag' or 'secret'
                ]

                # Check the target URL against the defined patterns
                # target_url = target_url.lower()
                for pattern in gopher_patterns:
                    if re.search(pattern, target_url):
                        print(pattern, target_url)
                        #logging.error(f"{pattern}, {target_url}")
                        return jsonify({"error": "Request blocked by WAF."}), 403
                target_url = target_url.lower()
                #if "://" in target_url:
                #    return jsonify({"error": ":// deleted from query, blocked by WAF"}), 403
                #target_url = target_url.replace("%20", "")

            return func(*args, **kwargs)

        return wrapper
    return decorator

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/robots.txt')
def robots():
    return render_template('robots.html')

def fetch_gopher(url):
    try:
        # Parse the Gopher URL to extract the host and path
        parsed_url = urlparse(url)
        host = 'gopher-server'  # Change to use service name
        port = parsed_url.port or 70  # Default Gopher port is 70
        path = parsed_url.path[1:] if parsed_url.path else ''  # Remove leading '/' if present

        logging.debug(f"Connecting to Gopher server at {host}:{port} with path '{path}'")
        
        # Create a socket connection to the Gopher server
        sock = socket.create_connection((host, port))
        sock.sendall((path + "\r\n").encode("utf-8"))
        
        # Receive the data
        response = b""
        while True:
            data = sock.recv(4096)
            if not data:
                break
            response += data
        sock.close()
        
        logging.debug("Gopher server response received successfully.")
        return response.decode("utf-8")
    except Exception as e:
        logging.error(f"Error connecting to Gopher server: {e}")
        return str(e)


@app.route('/fetch', methods=['GET'])
@waf()  # Apply WAF to the /fetch endpoint
def fetch():
    target_url = request.args.get('url')
    
    if not target_url:
        return jsonify({"error": "No URL provided"}), 400

    try:
        if target_url.lower().startswith("gopher://"):
            # Handle Gopher protocol separately
            data = fetch_gopher(target_url)
            return jsonify({"status": "success", "data": data}), 200
        else:
            # Handle regular HTTP/HTTPS URLs with requests
            response = requests.get(target_url)
            return jsonify({"status": "success", "data": response.text}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5757)
