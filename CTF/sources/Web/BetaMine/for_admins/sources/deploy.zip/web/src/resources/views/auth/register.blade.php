<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
</head>
<body>
    <div class="form-container">
        <h2>Register</h2>
        <form id="loginForm">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="button" onclick="registerUser()">Register</button>
        </form>
        <p id="loginMessage"></p>
    </div>
    <script>
        function registerUser() {
            const formData = new FormData(document.getElementById('loginForm'));
            fetch('/api/user/register', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.message === "Success") {
                    window.location.href = "/dashboard";
                } else {
                    document.getElementById('loginMessage').innerText = data.message;
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
