<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use App\Models\User;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin');
    }

    public function saveWebhook(Request $request)
    {
        $validated = $request->validate([
            'method' => 'required|in:GET,POST',
            'url' => 'required|url',
            'message' => 'required|string',
        ]);

        // in dev...
        return response()->json(['message' => 'Webhook settings saved successfully']);
    }

    public function testWebhook(Request $request)
    {
        $method = $request->input('method');
        $url = $request->input('url');
        $message = $request->input('message');

        if (!preg_match('/^https?:\/\//', $url)) {
            return response()->json(['message' => 'Invalid URL: Only HTTP and HTTPS protocols are allowed'], 400);
        }
        
        $client = new Client(['verify' => false]);

        try {
            $options = [
                'body' => $message,
                'connect_timeout' => 1.0,
                'read_timeout' => 1.5
            ];

            $response = $client->request($method, $url, $options);

            if ($response->getStatusCode() === 200) {
                return response()->json(['message' => 'Webhook test successful']);
            }

            return response()->json([
                'message' => "Webhook test failed with status {$response->getStatusCode()}"
            ], $response->getStatusCode());
        } catch (GuzzleException $e) {
            return response()->json(['message' => 'Webhook test failed'], 500);
        }
    }

    public function searchUser(Request $request)
    {
        $searchQuery = $request->input('search');

        $foundUsers = User::where('username', 'LIKE', '%' . $searchQuery . '%')->pluck('username');
        
        return response()->json(['found_users' => $foundUsers]);
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
        ]);

        $user = User::find($request->user_id);

        $newPassword = $this->generateRandomPassword(16);

        $user->password = Hash::make($newPassword);
        $user->save();

        return response()->json(['new_password' => $newPassword]);
    }

    private function generateRandomPassword($length = 16)
    {
        return substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()'), 0, $length);
    }
}
