<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class UserController extends Controller
{
    public function register(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required|unique:users',
            'password' => 'required'
        ]);

        $user = new User();
        $user->username = $validated['username'];
        $user->password = Hash::make($validated['password']);
        $user->is_admin = false;
        $user->blocked = false;
        $user->save();

        return response()->json(['message' => 'Success']);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('username', 'password');

        $user = User::where('username', $credentials['username'])->first();

        if ($user && Hash::check($credentials['password'], $user->password) && !$user->blocked) {
            Auth::login($user);
            $user->last_login = now();
            $user->save();

            return response()->json(['message' => 'Success']);
        }

        return response()->json(['message' => 'Invalid credentials or user is blocked'], 401);
    }
}
