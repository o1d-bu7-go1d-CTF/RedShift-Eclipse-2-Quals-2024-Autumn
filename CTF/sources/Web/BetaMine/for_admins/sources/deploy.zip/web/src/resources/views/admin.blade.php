<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
</head>
<body>
    <div class="admin-container">
        <h2>Admin Panel</h2>
        <h3>Webhook Settings</h3>
        <form id="webhookForm" onsubmit="event.preventDefault(); saveWebhook();">
            <label for="method">Method:</label>
            <select id="method" name="method" required>
                <option value="GET">GET</option>
                <option value="POST">POST</option>
            </select>
            <label for="url">Webhook URL:</label>
            <input type="url" id="url" name="url" required>
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
            <button type="submit">Save Webhook</button>
        </form>
        <button onclick="testWebhook()">Test Webhook</button>
        <p id="webhookMessage"></p>

        <h3>Search Users</h3>
        <form id="userSearchForm" onsubmit="searchUsers(event);">
            <label for="search">Search by Username:</label>
            <input type="text" id="search" name="search" required>
            <button type="submit">Search</button>
        </form>
        <div id="searchResults"></div>
    </div>

    <script>
        function saveWebhook() {
            const formData = new FormData(document.getElementById('webhookForm'));
            fetch('/api/admin/webhook', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('webhookMessage').innerText = data.message;
            })
            .catch(error => console.error('Error:', error));
        }

        function testWebhook() {
            const method = document.getElementById('method').value;
            const url = document.getElementById('url').value;
            const message = document.getElementById('message').value;

            fetch('/api/admin/test_webhook', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ method, url, message })
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById('webhookMessage').innerText = data.message;
            })
            .catch(error => console.error('Error:', error));
        }

        function searchUsers(event) {
            event.preventDefault();
            const searchQuery = document.getElementById('search').value;
            fetch(`/api/admin/search_user?search=${searchQuery}`)
                .then(response => response.json())
                .then(data => {
                    const resultsDiv = document.getElementById('searchResults');
                    resultsDiv.innerHTML = '<h4>Search Results:</h4>';
                    data.found_users.forEach(user => {
                        resultsDiv.innerHTML += `<p>${user}</p>`;
                    });
                })
                .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>