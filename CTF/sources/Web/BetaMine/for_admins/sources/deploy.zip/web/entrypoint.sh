#!/bin/sh

/wait-for-it.sh mysql:3306

php artisan migrate:fresh --force
php artisan db:seed --force

nginx && php-fpm