<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class AdminUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $randomPassword = Str::random(32);

        DB::table('users')->insert([
            'username' => 'admin',
            'password' => Hash::make($randomPassword),
            'is_admin' => true,
            'blocked' => false,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        $this->command->info("Admin created with username 'admin' and password: $randomPassword");
    }
}
