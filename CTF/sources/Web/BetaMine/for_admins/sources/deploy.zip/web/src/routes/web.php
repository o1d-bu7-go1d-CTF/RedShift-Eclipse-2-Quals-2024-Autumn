<?php
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;

Route::get('/', function () {
    if (Auth::check()) {
        return redirect('/dashboard');
    }
    return redirect('/login');
});
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::get('/dashboard', [AuthController::class, 'dashboard'])->middleware('auth');
Route::middleware(['auth', 'is_admin'])->get('/admin', [AdminController::class, 'index'])->name('admin');